<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Online Shopping</title>
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
</head>
<body>
      <div class="wrapper">
            <header>

                  <nav>

                        <div class="menu-icon">
                              <i class="fa fa-bars fa-2x"></i>
                        </div>

                        <div class="logo">
                          <?php

                           $email = $_POST['user'];
                            $password = $_POST['pass'];

                          $conn = mysqli_connect('localhost','root','','finalproject');

                          if($conn -> connect_error){
                            die("connection failed: " . $conn ->connect_error);

                          }

                          $sql = "select * from register where Email = '$email' && Password = '$password'  ";
                          $result = mysqli_query($conn,$sql);
                          $row = mysqli_fetch_array($result);


                          function phpAlert($msg) {
                              echo '<script type="text/javascript">alert("' . $msg . '")</script>';
                          }


                          if($row["Email"] == $email && $row["Password"] == $password  )
                          {
                            echo "Login success!!! Welcome " . $row['Email'];
                            session_start();
                            $_SESSION['user'] = $row['Email'];
                          }
                          else {
                            echo '<script>alert("Enter valid username and password")</script>';
                            echo '<script>window.location="index.php"</script>';
                          //  echo("Enter valid username and password");
                          }

                          ?>


                        </div>


                        <div class="menu">
                              <ul>
                                    <li><a href="home.php">Home</a></li>

                                       <li><a href="product.php" onclick="product()">Products Catalog</a></li>


                                    <li><a href="about.php">Contact us</a></li>
                                    <li><a href="location.php">Locations</a></li>
                                    <li><a href="index.php">Logout</a></li>
                              </ul>
                        </div>
                  </nav>

            </header>

            <div class="content">
              <p>
                Online Shopping in India
Clothes, electronics, accessories - whatever your need for the hour maybe, Flipkart, your favorite online shopping site, is sure to spoil you with a wide range of products. You don't have to wait for the weekends to shop as you can shop online on your way back home after work. Almost all popular brands across categories sell their products online, thereby bringing you closer to your preferences. Oh, and let's not forget about the various discounts on these products which make them an offer that is too hard to resist. So, are you all set to head online and shop? Let's take a look at what Flipkart has in store for you, shall we?
                               </p>
                               <p>
                                 Buying Guides - Your Assistants in Helping You Buy the Most Suitable Products
Sometimes, it can get a little overwhelming when you are exposed to a wide range of products. That's where the buying guides would come to your rescue. Flipkart has a set of guides that are specially curated to help you buy the right product across various categories. For example, if you would like to buy mobile phones online and are confused about what to pick, all you have to do is to click on the buying guide option. The guide will take you through the most important points to look for while buying a phone. You can also have a glance at the various reviews of the products posted by previous buyers that may help you make an informed buying decision. Convenient and simple, shop for your favorite appliances, gifts, and products online at Flipkart and let them arrive at your doorstep - one parcel at a time with a cheerful smile.
                               </p>
            </div>
      </div>

      <script type="text/javascript">

      // Menu-toggle button

function product()
{
  sessionStorage.setItem('name', document.getElementById('user').value);
  window.open("product.php");

}


      $(document).ready(function() {
            $(".menu-icon").on("click", function() {
                  $("nav ul").toggleClass("showing");
            });
      });

      // Scrolling Effect

      $(window).on("scroll", function() {
            if($(window).scrollTop()) {
                  $('nav').addClass('black');
            }

            else {
                  $('nav').removeClass('black');
            }
      })


      </script>

</body>
</html>
