<?php

  $name = $_POST['name'];
  $email = $_POST['email'];
  $message = $_POST['message'];

  $conn = mysqli_connect('localhost','root','','finalproject');

  if($conn -> connect_error){
    die("connection failed: " . $conn ->connect_error);

  }



$query = "insert into feedback (`Name`, `Email`, `Message`) VALUES ('$name','$email','$message')";
$result= mysqli_query($conn,$query);

if($result)
{

  echo '<script>alert("Thanks for your feedback Login to Shop again")</script>';
  echo '<script>window.location="index.php"</script>';
      //  echo '<script language="javascript">';
      //  echo 'alert("User Registered Continue to login")';
    //    echo '</script>';
        exit;


}
else {
echo"Data not Inserted";
}

?>
