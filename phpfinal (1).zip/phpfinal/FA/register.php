<!DOCTYPE html>
<html>
<head>
 <title> Login Form in HTML5 and CSS3</title>
<link rel="stylesheet" a href= " home.css">

</head>


<body>


 <div class="container">
 <img src="image/login.png"/>
 <form action = "registerquery.php" method = "POST" autocomplete="on">
 <div class="form-input">
 <input type="text" id = "user" name="user" required placeholder="Enter the User Name" name="Name"/>
 </div>
 <div class="form-input">
 <input type="text" id = "email" name="email"required placeholder="Enter E-mail" email ="Email"/>
 </div>
 <div class="form-input">
 <input type="password" id = "pass" name="pass"required placeholder="password" password = "Password"/>
 </div>


   <select id="sex" name="sex">
  <option value="0">--Select Gender--</option>
  <option value="Male">Male</option>
  <option value="Female">Female</option>

  </select>

 <div class="form-input">
 <input type="text" id = "dob" name="dob" required placeholder="Enter DOB" dob= "DOB"/>
 </div>
 <div class="form-input">
 <input type="text" id = "phone" name="phone" required placeholder="Enter Phone Number" phone = "Phone"/>
 </div>
 <div class="form-input">
 <input type="text" id = "address" name="address" required placeholder="Enter Address" address = "Address"/>
 </div>
 <input type="submit" type="submit" value="REGISTER"  class="btn-login"/>


 </div>
</body>
</html>
