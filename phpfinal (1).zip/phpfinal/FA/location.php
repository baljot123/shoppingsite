
<html>
<head>
<link rel="stylesheet" a href="location.css">

</head>
<body>
    <h4 id = "show">	</h4><br>
<var></var>

<div id ="content">
<iframe src="https://www.google.com/maps/d/u/1/embed?mid=1_E4O4pg3IfHA4Ng_o7g1RPAcbvaYGg8h" width="1357" height="480"></iframe><br><br>

</div><br><br>
<select id="location" name="location">
<option value="0">Select Nearest Location</option>
<option value="cllg">300 Cllg Blvd</option>
<option value="tulip">56 Tulip Drive</option>
<option value="Scarbrough">Town Center</option>
<option value="Markham">Main street 56</option>
<option value="Etobicoke">58 Steeles</option>

</select>

<input type="submit" type="submit" value="Continue"  onclick="check()" class="btn-login"/>


  <?php
   session_start();
   $name = $_SESSION['user'];
   ?>


  <script type="text/javascript">


   var jsName = '<?php echo $name; ?>';

   var myvar = document.getElementById('show').innerHTML =  ("WELCOME: " +  jsName );


  function check()
  {
    sessionStorage.setItem('name', document.getElementById('show').value);
    window.open("payment.php");
  }
</script>

</body>
</html>
