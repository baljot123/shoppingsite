
<!DOCTYPE html>
<html>
<head>
 <title> Online shopping</title>
 <link rel="stylesheet" a href="login.css">
 <link rel="stylesheet" a href="css\font-awesome.min.css">
</head>
<body>
 <div class="container">
 <img src="image/login.png"/>
 <form action = "home.php" method = "POST">
 <div class="form-input">
 <input type="text" id = "user" name="user"  placeholder="Enter the User Name"/>
 </div>
 <div class="form-input">
 <input type="password" id = "pass" name="pass"  placeholder="password"/>
 </div>
 <input type="submit" type="submit" value="LOGIN" class="btn-login"/>
 <input type="submit" type="submit" value="GUEST LOGIN" class="btn-login"/>


</form><br>
 <form action = register.php>
   <input type="submit" type="submit" value="REGISTER" class="btn-register"/>
 </form>
 </div>
</body>
</html>
