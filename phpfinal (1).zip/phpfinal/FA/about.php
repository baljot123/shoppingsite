<html>

<head>
  <title>About us</title>
    <link rel="stylesheet" href="about.css">
</head>

<body>
  <div class = "contact-title">
    <h1>Say Hello</h1>
    <h2> we are always ready to serve you !</h2>

    

    <div class="contact-form">

    <form  id = "contact-form" action = "aboutquery.php" method = "POST">

    <input type="name" id = "name" name="name" required class="form-control"  placeholder="Your Name"/><br>


    <input type="email" id = "email" name="email" required class="form-control"  placeholder="Your E-mail"/><br>


    <textarea id = "message" name="message"  class="form-control" required placeholder=" Message" rows="4"></textarea><br>

    <input type="submit" type="submit" value="Feedback" class="btn-login"/>

  </form>
</body>
</html>
