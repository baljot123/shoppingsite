-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2018 at 03:21 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finalproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `Name` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Name`, `Email`, `Message`) VALUES
('Baljot Singh', 'baljotsingh95@gmail.com', 'Hello!'),
('admin', 'admin123@gmail.com', 'welcome!'),
('q', 'abhi@gmail.com', 'qq');

-- --------------------------------------------------------

--
-- Table structure for table `paid`
--

CREATE TABLE IF NOT EXISTS `paid` (
  `Name` varchar(20) NOT NULL,
  `total` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paid`
--

INSERT INTO `paid` (`Name`, `total`) VALUES
('baljotsingh95@gmail.', '500'),
('baljotsingh95@gmail.', '500'),
('baljotsingh95@gmail.', '250'),
('baljotsingh95@gmail.', '250'),
('baljotsingh95@gmail.', '250'),
('baljotsingh95@gmail.', '250'),
('baljotsingh95@gmail.', ''),
('baljotsingh95@gmail.', '250'),
('baljotsingh95@gmail.', ''),
('baljotsingh95@gmail.', '50'),
('baljotsingh95@gmail.', '50'),
('baljotsingh95@gmail.', ''),
('baljotsingh95@gmail.', ''),
('', ''),
('', ''),
('', '200'),
('baljotsingh95@gmail.', ''),
('baljotsingh95@gmail.', '50');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `Name` varchar(50) NOT NULL,
  `payment` varchar(10) NOT NULL,
  `cardNumber` int(11) NOT NULL,
  `cvc` int(3) NOT NULL,
  `Bank` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`Name`, `payment`, `cardNumber`, `cvc`, `Bank`) VALUES
('Baljot', 'DEBIT CARD', 2147483647, 111, 'Scotia'),
('v', 'CREDIT CAR', 1234555, 566, 'Scotia'),
('a', 'DEBIT CARD', 2147483647, 1, 'Scotia'),
('f', 'DEBIT CARD', 123, 1, 'Scotia'),
('bf', 'DEBIT CARD', 2147483647, 321, 'f'),
('Baljot', 'DEBIT CARD', 2147483647, 0, 'ICICI'),
('ab', 'CREDIT CAR', 11, 111, 'ICICI'),
('Baljot', 'DEBIT CARD', 11, 111, 'ICICI'),
('acc', 'DEBIT CARD', 123, 123, 'Scotia'),
('ria', 'DEBIT CARD', 123, 332, 'ICICI'),
('ria', 'DEBIT CARD', 123, 332, 'ICICI'),
('ria', 'DEBIT CARD', 123, 332, 'ICICI'),
('ria somani', 'DEBIT CARD', 2147483647, 111, 'CIBC'),
('ac', 'CREDIT CAR', 98765321, 321, 'ICICI'),
('s', 'DEBIT CARD', 1, 1, 'CIBC'),
('zz', 'DEBIT CARD', 0, 111, 'Scotia'),
('aaa', 'CREDIT CAR', 987654321, 321, 'Scotia'),
('Baljot', 'CREDIT CAR', 33, 333, 'ICICI'),
('Sansoya', 'DEBIT CARD', 1, 11, 'Scotia');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `Name` varchar(40) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Sex` varchar(10) NOT NULL,
  `DOB` varchar(20) NOT NULL,
  `Phone` varchar(11) NOT NULL,
  `ADDRESS` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Name`, `Email`, `Password`, `Sex`, `DOB`, `Phone`, `ADDRESS`) VALUES
('Baljot', 'baljotsingh95@gmail.com', 'admin', 'Male', '12/01/1995', '4163179758', '56 tulip drive'),
('Baljot', '', '', '', '', '', ''),
('japapito', 'japapito@abc.com', 'japapito', 'Male', '20/12/01', '98876543210', 'toronto'),
('japapito', 'japapito@abc.com', 'asdf', '0', '20/12/01', '12233738939', '300,cllg blvd'),
('s', 'ac', 's', '0', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `name`, `image`, `price`) VALUES
(1, 'Head Phone', '9.jpg', 50.00),
(2, 'HP Notebook', '2.jpg', 299.00),
(3, 's9', 's9.jpg', 1125.00),
(4, 'Rolex', '4.jpg', 200.00),
(5, 'X-BOX', 'x.jpg', 250.00),
(6, 'LED TV', 'l.jpg', 300.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
