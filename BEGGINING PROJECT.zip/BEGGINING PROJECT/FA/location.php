
<html>
<head>
<link rel="stylesheet" a href="location.css">

</head>
<body>



<div id ="content">
<iframe src="https://www.google.com/maps/d/embed?mid=1_E4O4pg3IfHA4Ng_o7g1RPAcbvaYGg8h" text-align ="center" width="1350" height="500"></iframe><br><br>

</div><br><br>
<select id="location" name="location">
<option value="0">Select Nearest Location</option>
<option value="cllg">300 Cllg Blvd</option>
<option value="tulip">56 Tulip Drive</option>


</select>

<input type="submit" type="submit" value="Continue"  onclick="check()" class="btn-login"/>


  <script type="text/javascript">

  function check()
  {
    window.open("payment.php");
  }
</script>

</body>
</html>
