<?php

  $name = $_POST['user'];
  $payment = $_POST['payment'];
  $card = $_POST['card'];
  $cvc = $_POST['cvc'];
  $bank = $_POST['bank'];


  $conn = mysqli_connect('localhost','root','','finalproject');

  if($conn -> connect_error){
    die("connection failed: " . $conn ->connect_error);

  }


$query = "insert into payments(`Name`, `payment`, `cardNumber`, `cvc`, `Bank`) VALUES ('$name','$payment','$card','$cvc','$bank')";
$result= mysqli_query($conn,$query);

if($result)
{

  echo '<script>alert("your order is placed and and details were send to you via e-mail")</script>';
  echo '<script>window.location="home.php"</script>';
      //  echo '<script language="javascript">';
      //  echo 'alert("User Registered Continue to login")';
    //    echo '</script>';
        exit;


}
else {
echo"Data not Inserted";
}

?>
