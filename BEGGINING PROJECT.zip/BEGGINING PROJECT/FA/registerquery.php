<?php

  $name = $_POST['user'];
  $email = $_POST['email'];
  $password = $_POST['pass'];
  $gender = $_POST['sex'];
  $dob = $_POST['dob'];
  $phone = $_POST['phone'];
  $ADDRESS = $_POST['address'];

  $conn = mysqli_connect('localhost','root','','finalproject');

  if($conn -> connect_error){
    die("connection failed: " . $conn ->connect_error);

  }



$query = "insert into register (`Name`, `Email`, `Password`, `Sex`, `DOB`, `Phone`, `ADDRESS`) VALUES ('$name','$email','$password','$gender','$dob','$phone','$ADDRESS')";
$result= mysqli_query($conn,$query);

if($result)
{

  echo '<script>alert("Successfully registered continue to login")</script>';
  echo '<script>window.location="index.php"</script>';
      //  echo '<script language="javascript">';
      //  echo 'alert("User Registered Continue to login")';
    //    echo '</script>';
        exit;


}
else {
echo"Data not Inserted";
}

?>
