<!DOCTYPE html>
<html>
<head>
 <title> Online Shopping</title>
<link rel="stylesheet" a href= " payment.css">

</head>


<body>


 <div class="container">
 <img src="image/login.png"/>
 <form action = "paymentquery.php" method = "POST">
 <div class="form-input">
 <input type="text" id =  "user" name="user" required placeholder="Enter Name"/>
 </div>

   <select id="payment" name="payment">
  <option value="0">Select Payment Method</option>
  <option value="DEBIT CARD">DEBIT CARD</option>
  <option value="CREDIT CARD">CREDIT CARD</option>

    </select>


    <input type="number" id = "card" name="card"required placeholder="Card Number" min= "0"/>


    <input type="number" id = "cvc" name="cvc"required placeholder="cvc"  min= "0" max=""/>


 <div class="form-input">
 <input type="text" id = "bank" name="bank"required placeholder="Bank Name"/>
 </div>



 <input type="submit"  value="PAY"  class="btn-login"/>


 </div>
</body>
</html>
